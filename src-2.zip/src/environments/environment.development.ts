export const environment = {
    SPOTIFYAPI: "https://api.spotify.com/v1/"
};
