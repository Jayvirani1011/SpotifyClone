import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {map} from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ArtistsServiceService {
  private accessToken: string = 'BQDyULTZVvUO8kH9PrvNvbm_IKdwFHBS1gTM5VWzDCNkRZWZeCAtvsBxFvooQ0PrWh715e6xogml1pp0DUBO4GllwC6ilgBn7Em37bH14oqqoR4RRQeB';
  constructor(private http: HttpClient) { }

  getArtist(artistName: string) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.accessToken}`);
    // return this.http.get(`search?q=${artistName}&type=artist`, { headers });
    return this.http.get(`search?q=${artistName}&type=artist`, { headers }).pipe(map((val,index)=>{
      return {}
    }));
  }
}
