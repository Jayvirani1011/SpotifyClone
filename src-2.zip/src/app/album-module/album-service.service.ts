import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlbumServiceService {

  private accessToken: string = 'BQDyULTZVvUO8kH9PrvNvbm_IKdwFHBS1gTM5VWzDCNkRZWZeCAtvsBxFvooQ0PrWh715e6xogml1pp0DUBO4GllwC6ilgBn7Em37bH14oqqoR4RRQeB';
  
  // constructor(private http: HttpClient) {}

  // searchAlbum(albumName: string) {
  //   const headers = new HttpHeaders().set('Authorization', `Bearer ${this.accessToken}`);
  //   return this.http.get(`search?q=${albumName}&type=album`, { headers });
  // }

  constructor(private http: HttpClient) { }
  getAlbum(albumId: string): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.accessToken}`)
    console.log('albumId ' + albumId)
    return this.http.get(`albums/${albumId}`, { headers })
  }

  getTrack(albumId: string): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.accessToken}`)
    const url = `albums/${albumId}/tracks`;
    return this.http.get<any>(url, { headers })
    // });
  }

}

