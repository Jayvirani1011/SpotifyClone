import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlbumModuleRoutingModule } from './album-module-routing.module';
import { AlbumsComponent } from './albums.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AlbumsComponent
  ],
  imports: [
    CommonModule,
    AlbumModuleRoutingModule,
    FormsModule
  ]
})
export class AlbumModuleModule { }
