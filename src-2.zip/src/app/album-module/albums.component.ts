import { Component, OnInit } from '@angular/core';
import { AlbumServiceService } from './album-service.service';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css'],
})
export class AlbumsComponent {
  albumArtist: any;

  constructor(private albumService: AlbumServiceService) {}

  ngOnInit(): void {
    const albumId = '4aawyAB9vmqN3uQ7FjRGTy';
    this.albumService.getAlbum(albumId).subscribe(
      (response) => {
        this.albumArtist = response.tracks.items.flatMap(
          (track: any) => track.artists
        );
        console.log(response);
        console.log('albm item', this.albumArtist);
      },
      (error) => {
        console.log('Error', error);
      }
    );
  }

}
