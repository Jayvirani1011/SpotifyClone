export const environment = {
    SPOTIFYAPI: "https://api.spotify.com/v1/"
};


// 3 image print karva hoy to img tag ne loop ma nakhi devanu
// sun aa images array che to tare  array ne loop karavi ne badha url print karVA HOY TO KARAVI SAKE CHE OK ? NAY TO EK IMAGE PRINT KARAVU HOY TO ARRAY NO ZERO INDEX KARVANU 