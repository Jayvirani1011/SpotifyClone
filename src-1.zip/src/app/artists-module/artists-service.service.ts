import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArtistsServiceService {
  private accessToken: string = 'BQDhYaNsU3bKJ5SDq9XqUButRiDhcvxd9lP0hAATt50fMOm9vriUkXqJ0SNO19Gg0f9A2E_ul1Mx2AxSDaPHCt_Y4-lCPN2xv2ogCWOMdbVdDdUboRl6';
  constructor(private http: HttpClient) { }

  getArtist(artistName: string) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.accessToken}`);
    return this.http.get(`search?q=${artistName}&type=artist`, { headers });
  }
}
